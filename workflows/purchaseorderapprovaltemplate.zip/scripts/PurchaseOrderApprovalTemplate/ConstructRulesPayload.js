/*
// read from existing workflow context 
var userInfo = $.context.userInfo; 
var firstName = userInfo.firstName; 
var lastName = userInfo.lastName;

// read contextual information
var taskDefinitionId = $.info.taskDefinitionId;

// create new node 'request'
var request = {
		requestor: firstName + ' ' + lastName,
		workflowStep: taskDefinitionId
}

// write 'request' node to workflow context
$.context.request = request;
*/
$.context.PurchaseOrder.__type__ = "PurchaseOrder";
